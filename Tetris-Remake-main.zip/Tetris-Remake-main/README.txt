This is a free and open source project made in Python!
Instructions (Must Read!)
You need to be having Python and pygame!
use the arrow keys to move the block and up arrow to turn the block







Read the code file for the code.
